import ChatConversation from "../models/chatconversation.js";
import ChatMessage from "../models/chatmessage.js";
import User from "../models/user.js";
import sequelize from "../config/connection.js";
import { Op } from "sequelize";
//Fetch chat messages between two users
export const FetchChat = async(req,res)=>{
    const { userOne, userTwo } = req.params;

  try {
    const conversation = await ChatConversation.findOne({
      where: {
        [Op.or]: [
          { user_one: userOne, user_two: userTwo },
          { user_one: userTwo, user_two: userOne },
        ],
      },
      include: [{ model: ChatMessage, as: 'ChatMessages' }],
    });
   
    res.json(conversation?.ChatMessages || []);
  } catch (error) {
    console.error('Error fetching chat:', error);
    res.status(500).json([]);
  }
};

//Fetch list of previous chats for a user
export const FetchUserChats = async (req,res) =>{
    const { userId } = req.params;
    

  try {
    const chats = await ChatConversation.findAll({
      where: {
        [Op.or]: [
          { user_one: userId },
          { user_two: userId },
        ],
      },
      include: [
        { model: User, as: 'UserOne', attributes: ['id', 'name', 'main_image', 'last_seen'] },
        { model: User, as: 'UserTwo', attributes: ['id', 'name', 'main_image', 'last_seen'] },
        { model: ChatMessage, as: 'ChatMessages', order: [['createdAt', 'ASC']] },
      ],
    });
    
    if (!chats) {
      return res.json([]);
    }

    res.json(chats);
  } catch (error) {
    console.error('Error fetching chats:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

//Fetch chat by ID
export const FtechChatById = async(req,res) =>{
    const {chatId} = req.params;
    try {
        const chat= await  ChatConversation.findOne({
           where:{
             id:chatId
           },
           include: [
             { model: User, as: 'UserOne', attributes: ['id','name' , 'main_image', 'last_seen'] },
             { model: User, as: 'UserTwo', attributes: ['id','name', 'main_image','last_seen']},
             { model: ChatMessage, as: 'ChatMessages', order: [['createdAt', 'DESC']]},
           ],
         })
           res.json(chat);
        
    } catch (error) {
        console.error('Error fetching chats:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

//Create new temp chat
export const CreateChatIfNotExists = async(req,res) =>{
    const { id1, id2 } = req.params;
    const conv = await ChatConversation.findOne({
      where: {
        [Op.or]: [
          { user_one: id1, user_two: id2 },
          { user_two: id1, user_one: id2 },
        ],
      },
      include: [
        { model: User, as: 'UserOne', attributes: ['id','name' , 'main_image', 'last_seen'] },
        { model: User, as: 'UserTwo', attributes: ['id','name', 'main_image','last_seen']},
        { model: ChatMessage, as: 'ChatMessages', order: [['createdAt', 'DESC']]},
      ],
    });
    if(conv){
      return res.json(conv);
      
    }
    
    const newConversation = await ChatConversation.create({
      user_one: id1,
      user_two: id2,
    });
    const chat = await ChatConversation.findOne({
      where: {
        id: newConversation.id
      },
      include: [
        { model: User, as: 'UserOne', attributes: ['id','name' , 'main_image', 'last_seen'] },
        { model: User, as: 'UserTwo', attributes: ['id','name', 'main_image','last_seen']},
        { model: ChatMessage, as: 'ChatMessages', order: [['createdAt', 'DESC']]},
      ],
    });
    res.json(chat)
};

// Delete chat by ID
export const DeleteChat = async(req,res) =>{
    const { chatId } = req.params;
  
    try {
      await ChatConversation.destroy({
        where: {
          id: chatId,
        },
      });
      res.json({ message: 'Chat deleted!'})
    }catch(error){
      console.log(error); 
    }
};

// Delete chat messaged
export const DeleteChatMessages = async(req,res) =>{
    try {
        const { chatId, userId } = req.params;
    
        // Add user to deleted_by for all messages in the chat
        await ChatMessage.update(
          {  deleted_by: sequelize.fn('JSON_ARRAY_APPEND', 
            sequelize.col('deleted_by'), 
            '$', 
            userId
          ) },
          {
            where: {
              conversation_id: chatId
            }
          }
        );
    
        res.json({ success: true });
      } catch (error) {
        console.error('Error deleting chat:', error);
        res.status(500).json({ success: false });
      }

};