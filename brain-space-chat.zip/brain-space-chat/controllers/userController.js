import User from "../models/user.js";

export const FetchUsers = async (req,res) =>{
    const users = await User.findAll();
    res.json(users);
};