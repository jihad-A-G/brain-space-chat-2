import ChatMessage from "../models/chatmessage.js";

// Upload attachments messages to the server
export const UploadAttachment = async(req,res) =>{
    const { filename, originalname, size } = req.file;
  
    // Extract extension from original filename
    const file_extension = originalname.split('.').pop();
    
    const file_url = `/uploads/${filename}`;
    res.json({ 
      file_url,
      file_name: originalname,
      file_extension,
      file_size: size
    });
};

// Update all chat messaged to read
export const MarkMessageAsRead = async(req,res) =>{

    const { conversationId, userId } = req.body;
    
    try {
      await ChatMessage.update(
        { is_read: true },
        {
          where: {
            conversation_id: conversationId,
            receiver_id: userId,
            is_read: false
          }
        }
      );

      // Get the updated messages
      const updatedMessages = await ChatMessage.findAll({
        where: {
          conversation_id: conversationId,
          receiver_id: userId
        }
      });
  
      io.to(conversationId).emit('messagesRead', updatedMessages);
      res.status(200).json({ success: true });
    } catch (error) {
      console.error('Error marking messages as read:', error);
      res.status(500).json({ success: false });
    }
};