import  jwt  from 'jsonwebtoken'
import dotenv from 'dotenv'
dotenv.config()

const authenticate = async(req,res,next) =>{
    const token = req.headers['authorization']
    try {

        if(!token){
            return res.status(401).json({status:401, message: 'Invalid token!'})
        }
        const decoded = jwt.verify(token.split(' ')[1], process.env.JWT_SECRET)

        if(!decoded){
            return res.status(401).json({status:401, message:'User not found'})
        }

        req.user = decoded.user
        next()
    } catch (err) {
        next(err)
    }
    
}

export default authenticate