import User from './models/user.js';
import ChatBlockedUser from './models/chatblockeduser.js';
import ChatConversation from './models/chatconversation.js';
import ChatDeletedMessage from './models/chatdeletedmessage.js';
import ChatMessage from './models/chatmessage.js';

ChatBlockedUser.belongsTo(User, { foreignKey: 'blocker_id', as: 'Blocker' });
ChatBlockedUser.belongsTo(User, { foreignKey: 'blocked_id', as: 'Blocked' });

ChatConversation.belongsTo(User, { foreignKey: 'user_one', as: 'UserOne' });
ChatConversation.belongsTo(User, { foreignKey: 'user_two', as: 'UserTwo' });
ChatConversation.hasMany(ChatMessage, { foreignKey: 'conversation_id', as: 'ChatMessages' });

ChatDeletedMessage.belongsTo(ChatMessage, { foreignKey: 'message_id', as: 'Message' });
ChatDeletedMessage.belongsTo(User, { foreignKey: 'deleted_by', as: 'DeletedBy' });

ChatMessage.belongsTo(ChatConversation, { foreignKey: 'conversation_id', as: 'Conversation' });
    ChatMessage.belongsTo(User, { foreignKey: 'sender_id', as: 'Sender' });
    ChatMessage.belongsTo(User, { foreignKey: 'receiver_id', as: 'Receiver' });

    User.hasMany(ChatConversation, { foreignKey: 'user_one', as: 'UserOneConversations' });
User.hasMany(ChatConversation, { foreignKey: 'user_two', as: 'UserTwoConversations' });
