import { DataTypes } from 'sequelize';
import sequelize from '../config/connection.js';

const ChatDeletedMessage = sequelize.define('ChatDeletedMessage', {
    message_id: { type: DataTypes.INTEGER, allowNull: false },
    deleted_by: { type: DataTypes.INTEGER, allowNull: false },
  }, {timestamps:false});

   
export default ChatDeletedMessage;