import { DataTypes } from "sequelize";
import sequelize from "../config/connection.js";

  const User = sequelize.define('user', {
    name: { type: DataTypes.STRING, allowNull: false },
    user_name: { type: DataTypes.STRING, allowNull: false, unique: true },
    password: { type: DataTypes.STRING, allowNull: false },
    phone_number: { type: DataTypes.STRING, allowNull: false },
    email_address: { type: DataTypes.STRING, allowNull: false },
    gender: { type: DataTypes.ENUM('Male', 'Female'), allowNull: false },
    disabled: { type: DataTypes.BOOLEAN, defaultValue: false },
    role: { type: DataTypes.INTEGER, allowNull: false },
    main_image: { type: DataTypes.STRING, allowNull: true },
    token: { type: DataTypes.TEXT, allowNull: false },
    mobile_token: { type: DataTypes.STRING(1000), allowNull: false },
    secret_key: { type: DataTypes.STRING, allowNull: true },
    language_id: { type: DataTypes.INTEGER, defaultValue: 1 },
    last_seen: { type: DataTypes.DATE, allowNull: true },
    status:{ type: DataTypes.STRING, allowNull: true },
  }, {timestamps:false});
  
export default User