import { DataTypes } from 'sequelize';
import sequelize from '../config/connection.js';

  const ChatMessage = sequelize.define('ChatMessage', {
    conversation_id: { type: DataTypes.INTEGER, allowNull: false },
    sender_id: { type: DataTypes.INTEGER, allowNull: false },
    receiver_id: { type: DataTypes.INTEGER, allowNull: false },
    message: { type: DataTypes.TEXT, allowNull: false },
    message_type: { type: DataTypes.ENUM('text', 'image', 'video', 'file', 'audio'), defaultValue: 'text' },
    file_url: { type: DataTypes.STRING, allowNull: true },
    file_name: { type: DataTypes.STRING, allowNull: true },
    file_extension: { type: DataTypes.STRING, allowNull: true },
    file_size: { type: DataTypes.STRING, allowNull: true },
    is_read: { type: DataTypes.BOOLEAN, defaultValue: false },
    deleted_by: { 
      type: DataTypes.JSON,
      defaultValue: [] 
    }
  }, {timestamps:true});

    
export default ChatMessage;
