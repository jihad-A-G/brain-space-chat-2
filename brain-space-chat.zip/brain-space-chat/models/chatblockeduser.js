import { DataTypes } from 'sequelize';
import sequelize from '../config/connection.js';

  const ChatBlockedUser = sequelize.define('ChatBlockedUser', {
    blocker_id: { type: DataTypes.INTEGER, allowNull: false },
    blocked_id: { type: DataTypes.INTEGER, allowNull: false },
  }, {timestamps:false});

   


 export default ChatBlockedUser;
