import { DataTypes } from "sequelize";
import sequelize from "../config/connection.js";

  const ChatConversation = sequelize.define('ChatConversation', {
    user_one: { type: DataTypes.INTEGER, allowNull: false },
    user_two: { type: DataTypes.INTEGER, allowNull: false },
    }, {timestamps:false});

   
  export default ChatConversation;