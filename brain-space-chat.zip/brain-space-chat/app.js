import express from "express";
import http from 'http';
import {Server} from 'socket.io';
import { Sequelize} from "sequelize";
import cors from 'cors';
import dotenv from "dotenv";
import helmet from "helmet";
import morgan from "morgan";
import ChatMessage from "./models/chatmessage.js";
import User from "./models/user.js";
import "./association.js";
import chatRouter from "./routers/chatRoutes.js";
import messageRouter from "./routers/messageRoutes.js";
import userRouter from "./routers/userRoutes.js";
import sequelize from "./config/connection.js";
dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

//Allow all origins to access the server
app.use(cors());
// Parse incoming requests data as json
app.use(express.json());
// Parse incoming requests data as urlencoded
app.use(express.urlencoded({ extended: true }));

// HTTP request logger
app.use(morgan('dev'));

// Serve static files
app.use("/uploads", express.static("uploads"));

// Routes
app.use ('/api/chats', chatRouter);
app.use('/api/messages', messageRouter);
app.use('/api/users', userRouter);

//Initialize websocket server
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
  },
});

// sync database connection
await sequelize.sync({ force: false, alter:false });


// Map to store online users
let onlineUsers = new Map();
// Set to store active conversations
let activeConversations = new Set();
  
  // Socket.IO connection
  io.on('connection', async (socket) => {
    console.log('A user connected:', socket.id);


    socket.on('joinRoom', async (data) => {
      const id = data;
      socket.join(id);
      console.log(`User ${id} joined room ${id}`);
    });
    socket.on('joinConversation', (conversationId) => {
      socket.join(conversationId);
      activeConversations.add(conversationId);
    });
    
    socket.on('leaveConversation', (conversationId) => {
      socket.leave(conversationId);
      activeConversations.delete(conversationId);
    });

    socket.on('login', async (data) =>{
        
      const id = data;      
      socket.userId = id;
      onlineUsers.set(id, {
        lastSeen: new Date(),
        sockets: new Set([socket.id])
      });
      await User.update({last_seen:null, status:"Online"},{where:{id:id}})
        io.emit('Online', id); // Notify all clients that the user is online
    });

    socket.on('markMessagesRead', async ({ conversationId, receiver_id, sender_id }) => {
      try {
        // Update messages in database
        await ChatMessage.update(
          { is_read: true },
          {
            where: {
              conversation_id: conversationId,
              receiver_id: receiver_id,
              is_read: false
            }
          }
        );
    
        // Get updated messages
        const updatedMessages = await ChatMessage.findAll({
          where: { conversation_id: conversationId }
        });
    
        // Emit the updated messages to all clients in the conversation
        io.to(conversationId).emit('messagesRead', updatedMessages);
      } catch (error) {
        console.error('Error marking messages as read:', error);
      }
    });
    socket.on('presence', ({ userId }) => {
      
      if (onlineUsers.has(userId)) {
        onlineUsers.get(userId).lastSeen = new Date();
      }
      
    });

    socket.on('updateStatus', async (data) =>{
      const {id, status} = data;
      await User.update({status},{where:{id:id}});

      io.emit('statusUpdated', {id, status});
    })


    // Listen for new messages
    socket.on('sendMessage', async (data) => {
      let { conversation_id, sender_id, receiver_id, message, message_type, file_url, file_name, file_extension, file_size } = data;
       
      try {
       
        let newMessage = await ChatMessage.create({
          conversation_id: conversation_id,
          sender_id: sender_id,
          receiver_id: receiver_id,
          message: message,
          message_type:file_url && file_url !=="" ?message_type:"text", 
          file_url: file_url? file_url: null,
          file_name : file_name? file_name: null,
          file_extension : file_extension? file_extension: null,
          file_size : file_size? file_size: null,
        });
        
    
        const user = await User.findByPk(sender_id);
        
        io.to(receiver_id).emit('receiveMessage', newMessage);
        newMessage = { ...newMessage, user };
        io.to(receiver_id).emit('notifyMessage', newMessage);
      } catch (error) {
        console.error('Error saving message:', error);
      }
    });
  
  socket.on('disconnect', async () => {
    if (socket.userId) {
      console.log(`User of id ${socket.userId} is disconnected `);
      
      const userEntry = onlineUsers.get(socket.userId);
      if (userEntry) {
        userEntry.sockets.delete(socket.id);
        
        if (userEntry.sockets.size === 0) {
          await User.update(
            { last_seen: new Date(), status:"Offline" },
            { where: { id: socket.userId } }
          );
          onlineUsers.delete(socket.userId);
          io.emit('Offline', socket.userId);
        }
      }
      activeConversations.forEach(conversationId => {
        socket.leave(conversationId);
      });
    
    }
  });
});


server.listen(PORT, () => {
  console.log(`Backend server running at port: ${PORT}`);
});