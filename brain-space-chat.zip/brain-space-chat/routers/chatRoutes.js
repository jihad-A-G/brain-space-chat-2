import {Router} from 'express';

import * as chatController from '../controllers/chatController.js';

const router = Router();

router.get('/userChats/:userId', chatController.FetchUserChats);
router.get('/:userOne/:userTwo', chatController.FetchChat);
router.get('/:chatId', chatController.FtechChatById);
router.get('/newchat/:id1/:id2', chatController.CreateChatIfNotExists);
router.delete('/:chatId', chatController.DeleteChat);
router.delete('/:chatId/:userId', chatController.DeleteChatMessages);

export default router;
