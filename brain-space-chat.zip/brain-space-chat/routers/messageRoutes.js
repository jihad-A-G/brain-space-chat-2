import {Router} from 'express';
import * as messageController from '../controllers/messageController.js';
import upload from '../config/multer.js';

const router = Router();

router.post('/upload',upload.single('file'), messageController.UploadAttachment);

router.put('/mark-read', messageController.MarkMessageAsRead);

export default router;